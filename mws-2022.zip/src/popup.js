'use strict';

import './popup.css';
const popupMenusModule = require('./popupMenusScript.js');

(function () {
  function setupPopupMenus(initialValue = 'undefined') {
    document.getElementById('saveLocation').innerHTML = initialValue;

    document.getElementById('judgingBtn').addEventListener('click', () => {
      popupMenusModule.popupMenus.judgeWebPage()
    });

    document.getElementById('savingBtn').addEventListener('click', () => {
      popupMenusModule.popupMenus.saveWebPageInfo()
    });

    document.getElementById('settingsBtn').addEventListener('click', () => {
      popupMenusModule.popupMenus.changeSettings()
      updateSettings()
    });
  }

  function updateSettings() {
    popupMenusModule.uriManager.get((saveLocation) => {
      popupMenusModule.popupMenus.changeSettings()

      popupMenusModule.uriManager.set(saveLocation, () => {
        document.getElementById('counter').innerHTML = saveLocation;
      });
    });

    return true;
  }

  function restoreSaveLocation() {
    popupMenusModule.uriManager.get((saveLocation) => {
      if (typeof saveLocation === 'undefined') {
        popupMenusModule.uriManager.set('NoSetting', () => {
          setupPopupMenus('NoSetting');
        });
      } else {
        setupPopupMenus(saveLocation);
      }
    });
  }

  document.addEventListener('DOMContentLoaded', restoreSaveLocation);

  // Communicate with background file by sending a message
  chrome.runtime.sendMessage(
    {
      type: 'GREETINGS',
      payload: {
        message: 'Hello, my name is Pop. I am from Popup.',
      },
    },
    (response) => {
      console.log(response.message);
    }
  );
})();

'use strict';

const uriManager = {
    get: (cb) => {
        chrome.storage.sync.get(['uri'], (result) => {
            cb(result.uri);
        });
    },
    set: (value, cb) => {
        chrome.storage.sync.set({
            uri: value
        },
        () => {
            cb();
        });
    }
}

module.exports.popupMenus = {
    judgeWebPage: (url) => {
        uriManager.set('test1')
        console.log('Judge Web Page.')
    },
    saveWebPageInfo: (url) => {
        uriManager.set('test2')
        console.log('Save Web Page.')
    },
    changeSettings: (url) => {
        uriManager.set('test3')
        console.log('Change Settings.')
    }
};

module.exports.uriManager = uriManager
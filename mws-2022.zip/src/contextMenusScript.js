'use strict';

module.exports.saveWebInfo = {
    saveUrl: (url) => {
        console.log('saving')
    }
};
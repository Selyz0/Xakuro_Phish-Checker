'use strict';

const contextMenusModule = require('./contextMenusScript.js')

// With background scripts you can communicate with popup
// and contentScript files.
// For more information on background script,
// See https://developer.chrome.com/extensions/background_pages
{
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'GREETINGS') {
      const message = `Hi ${
        sender.tab ? 'Con' : 'Pop'
      }, my name is Bac. I am from Background. It's great to hear from you.`;

      // Log message coming from the `request` parameter
      console.log(request.payload.message);
      // Send a response message
      sendResponse({
        message,
      });
    }
    
    return true;
  });
}

{
  chrome.runtime.onInstalled.addListener(() => {
    const parent = chrome.contextMenus.create({
        id: 'parent',
        title: 'MWS-2022'
    });
    chrome.contextMenus.create({
        id: 'SAVE',
        parentId: 'parent',
        title:  'フィッシングページ情報を保存する'
    });
  });

  // Listen for rightclick menu
  chrome.contextMenus.onClicked.addListener(item => {
    console.log(`You clicked ${item.menuItemId} button.`);

    if (item.menuItemId == 'SAVE'){
      contextMenusModule.saveWebInfo.saveUrl('url')
      console.log('Saved some information.');
    }
    return true;
  });
}